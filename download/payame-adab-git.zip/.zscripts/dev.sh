#!/bin/bash

set -euo pipefail

# 获取脚本所在目录（.zscripts）
# 使用 $0 获取脚本路径（与 build.sh 保持一致）
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

log_step_start() {
        local step_name="$1"
        echo "=========================================="
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] Starting: $step_name"
        echo "=========================================="
        export STEP_START_TIME
        STEP_START_TIME=$(date +%s)
}

log_step_end() {
        local step_name="${1:-Unknown step}"
        local end_time
        end_time=$(date +%s)
        local duration=$((end_time - STEP_START_TIME))
        echo "=========================================="
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] Completed: $step_name"
        echo "[LOG] Step: $step_name | Duration: ${duration}s"
        echo "=========================================="
        echo ""
}

start_mini_services() {
        local mini_services_dir="$PROJECT_DIR/mini-services"
        local started_count=0

        log_step_start "Starting mini-services"
        if [ ! -d "$mini_services_dir" ]; then
                echo "Mini-services directory not found, skipping..."
                log_step_end "Starting mini-services"
                return 0
        fi

        echo "Found mini-services directory, scanning for sub-services..."

        for service_dir in "$mini_services_dir"/*; do
                if [ ! -d "$service_dir" ]; then
                        continue
                fi

                local service_name
                service_name=$(basename "$service_dir")
                echo "Checking service: $service_name"

                if [ ! -f "$service_dir/package.json" ]; then
                        echo "[$service_name] No package.json found, skipping..."
                        continue
                fi

                if ! grep -q '"dev"' "$service_dir/package.json"; then
                        echo "[$service_name] No dev script found, skipping..."
                        continue
                fi

                echo "Starting $service_name in background..."
                (
                        cd "$service_dir"
                        echo "[$service_name] Installing dependencies..."
                        bun install
                        echo "[$service_name] Running bun run dev..."
                        exec bun run dev
                ) >"$PROJECT_DIR/.zscripts/mini-service-${service_name}.log" 2>&1 &

                local service_pid=$!
                echo "[$service_name] Started in background (PID: $service_pid)"
                echo "[$service_name] Log: $PROJECT_DIR/.zscripts/mini-service-${service_name}.log"
                disown "$service_pid" 2>/dev/null || true
                started_count=$((started_count + 1))
        done

        echo "Mini-services startup completed. Started $started_count service(s)."
        log_step_end "Starting mini-services"
}

wait_for_service() {
        local host="$1"
        local port="$2"
        local service_name="$3"
        local max_attempts="${4:-60}"
        local attempt=1

        echo "Waiting for $service_name to be ready on $host:$port..."

        while [ "$attempt" -le "$max_attempts" ]; do
                if curl -s --connect-timeout 2 --max-time 5 "http://$host:$port" >/dev/null 2>&1; then
                        echo "$service_name is ready!"
                        return 0
                fi

                echo "Attempt $attempt/$max_attempts: $service_name not ready yet, waiting..."
                sleep 1
                attempt=$((attempt + 1))
        done

        echo "ERROR: $service_name failed to start within $max_attempts seconds"
        return 1
}

cleanup() {
        if [ -n "${DEV_PID:-}" ] && kill -0 "$DEV_PID" >/dev/null 2>&1; then
                echo "Stopping Next.js dev server (PID: $DEV_PID)..."
                kill "$DEV_PID" >/dev/null 2>&1 || true
        fi
}

trap cleanup EXIT INT TERM

cd "$PROJECT_DIR"

if ! command -v bun >/dev/null 2>&1; then
        echo "ERROR: bun is not installed or not in PATH"
        exit 1
fi

log_step_start "bun install"
echo "[BUN] Installing dependencies..."
bun install
log_step_end "bun install"

log_step_start "bun run db:push"
echo "[BUN] Setting up database..."
bun run db:push
log_step_end "bun run db:push"

# Automatic safety backup before every boot (keeps the newest 14, at most one per day)
auto_backup() {
        local backup_dir="$PROJECT_DIR/db/backups"
        mkdir -p "$backup_dir" || return 0
        local today stamp target
        today=$(date '+%Y-%m-%d')
        stamp=$(date '+%Y-%m-%d-%H%M%S')
        target="$backup_dir/payameadab-$stamp.db"
        # skip if a backup for today already exists
        if ls "$backup_dir"/payameadab-"$today"-*.db >/dev/null 2>&1; then
                echo "[BACKUP] Backup for $today already exists — skipping."
        else
                node -e "const {PrismaClient}=require('@prisma/client');const p=new PrismaClient();p.\$executeRawUnsafe(\"VACUUM INTO '$target'\").then(()=>p.\$disconnect()).catch(e=>{console.error(String(e).slice(0,200));process.exit(1)})" \
                        && echo "[BACKUP] Created $target" \
                        || echo "[BACKUP] Backup failed (non-fatal, continuing boot)"
        fi
        # keep only the newest 14 backups
        ls -1t "$backup_dir"/payameadab-*.db 2>/dev/null | tail -n +15 | while read -r old; do rm -f "$old"; done
}
auto_backup || true

log_step_start "Starting server (production standalone if available)"
# Prefer the production standalone build (fast boot, no Turbopack dev OOM).
# Fall back to next dev when no standalone build exists yet.
if [ -f "$PROJECT_DIR/.next/standalone/server.js" ] && [ -d "$PROJECT_DIR/.next/standalone/.next/static" ]; then
        echo "[SERVER] Starting production standalone server..."
        set -a
        # shellcheck disable=SC1091
        source "$PROJECT_DIR/.env" 2>/dev/null || true
        set +a
        export NODE_ENV=production
        export PORT=3000
        export HOSTNAME=0.0.0.0
        (cd "$PROJECT_DIR/.next/standalone" && exec node server.js) > "$PROJECT_DIR/server.log" 2>&1 &
        DEV_PID=$!
else
        echo "[BUN] No standalone build found — starting development server..."
        bun run dev &
        DEV_PID=$!
fi
log_step_end "Starting server (production standalone if available)"

log_step_start "Waiting for Next.js dev server"
wait_for_service "localhost" "3000" "Next.js dev server"
log_step_end "Waiting for Next.js dev server"

log_step_start "Health check"
echo "[BUN] Performing health check..."
curl -fsS localhost:3000 >/dev/null
echo "[BUN] Health check passed"
log_step_end "Health check"

start_mini_services

echo "Next.js dev server is running in background (PID: $DEV_PID)."
echo "Use 'kill $DEV_PID' to stop it."
disown "$DEV_PID" 2>/dev/null || true
unset DEV_PID
